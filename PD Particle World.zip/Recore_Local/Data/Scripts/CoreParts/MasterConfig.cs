﻿
namespace Scripts
{
    partial class Parts
    {
        internal Parts()
        {
            // naming convention: WeaponDefinition Name
            //
            // Enable your definitions using the follow syntax:
            // PartDefinitions(Your1stDefinition, Your2ndDefinition, Your3rdDefinition);
            // PartDefinitions includes both weapons and phantoms
            PartDefinitions(Starcore_SSRM,
            Starcore_MRM,
            Starcore_LRM,
            Starcore_PPC,
            Starcore_Arrow,
            Starcore_ArmourLRM,
            Starcore_AMS_I,
            Starcore_AMS_II
			);

        }
    }
}
